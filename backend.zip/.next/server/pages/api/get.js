"use strict";
/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
(() => {
var exports = {};
exports.id = "pages/api/get";
exports.ids = ["pages/api/get"];
exports.modules = {

/***/ "next/dist/compiled/next-server/pages-api.runtime.dev.js":
/*!**************************************************************************!*\
  !*** external "next/dist/compiled/next-server/pages-api.runtime.dev.js" ***!
  \**************************************************************************/
/***/ ((module) => {

module.exports = require("next/dist/compiled/next-server/pages-api.runtime.dev.js");

/***/ }),

/***/ "fs":
/*!*********************!*\
  !*** external "fs" ***!
  \*********************/
/***/ ((module) => {

module.exports = require("fs");

/***/ }),

/***/ "path":
/*!***********************!*\
  !*** external "path" ***!
  \***********************/
/***/ ((module) => {

module.exports = require("path");

/***/ }),

/***/ "(api)/./node_modules/next/dist/build/webpack/loaders/next-route-loader/index.js?kind=PAGES_API&page=%2Fapi%2Fget&preferredRegion=&absolutePagePath=.%2Fpages%2Fapi%2Fget.js&middlewareConfigBase64=e30%3D!":
/*!************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/next/dist/build/webpack/loaders/next-route-loader/index.js?kind=PAGES_API&page=%2Fapi%2Fget&preferredRegion=&absolutePagePath=.%2Fpages%2Fapi%2Fget.js&middlewareConfigBase64=e30%3D! ***!
  \************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   config: () => (/* binding */ config),\n/* harmony export */   \"default\": () => (__WEBPACK_DEFAULT_EXPORT__),\n/* harmony export */   routeModule: () => (/* binding */ routeModule)\n/* harmony export */ });\n/* harmony import */ var next_dist_server_future_route_modules_pages_api_module_compiled__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! next/dist/server/future/route-modules/pages-api/module.compiled */ \"(api)/./node_modules/next/dist/server/future/route-modules/pages-api/module.compiled.js\");\n/* harmony import */ var next_dist_server_future_route_modules_pages_api_module_compiled__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_dist_server_future_route_modules_pages_api_module_compiled__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var next_dist_server_future_route_kind__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! next/dist/server/future/route-kind */ \"(api)/./node_modules/next/dist/server/future/route-kind.js\");\n/* harmony import */ var next_dist_build_templates_helpers__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! next/dist/build/templates/helpers */ \"(api)/./node_modules/next/dist/build/templates/helpers.js\");\n/* harmony import */ var _pages_api_get_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./pages/api/get.js */ \"(api)/./pages/api/get.js\");\n\n\n\n// Import the userland code.\n\n// Re-export the handler (should be the default export).\n/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ((0,next_dist_build_templates_helpers__WEBPACK_IMPORTED_MODULE_2__.hoist)(_pages_api_get_js__WEBPACK_IMPORTED_MODULE_3__, \"default\"));\n// Re-export config.\nconst config = (0,next_dist_build_templates_helpers__WEBPACK_IMPORTED_MODULE_2__.hoist)(_pages_api_get_js__WEBPACK_IMPORTED_MODULE_3__, \"config\");\n// Create and export the route module that will be consumed.\nconst routeModule = new next_dist_server_future_route_modules_pages_api_module_compiled__WEBPACK_IMPORTED_MODULE_0__.PagesAPIRouteModule({\n    definition: {\n        kind: next_dist_server_future_route_kind__WEBPACK_IMPORTED_MODULE_1__.RouteKind.PAGES_API,\n        page: \"/api/get\",\n        pathname: \"/api/get\",\n        // The following aren't used in production.\n        bundlePath: \"\",\n        filename: \"\"\n    },\n    userland: _pages_api_get_js__WEBPACK_IMPORTED_MODULE_3__\n});\n\n//# sourceMappingURL=pages-api.js.map//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiKGFwaSkvLi9ub2RlX21vZHVsZXMvbmV4dC9kaXN0L2J1aWxkL3dlYnBhY2svbG9hZGVycy9uZXh0LXJvdXRlLWxvYWRlci9pbmRleC5qcz9raW5kPVBBR0VTX0FQSSZwYWdlPSUyRmFwaSUyRmdldCZwcmVmZXJyZWRSZWdpb249JmFic29sdXRlUGFnZVBhdGg9LiUyRnBhZ2VzJTJGYXBpJTJGZ2V0LmpzJm1pZGRsZXdhcmVDb25maWdCYXNlNjQ9ZTMwJTNEISIsIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7OztBQUFzRztBQUN2QztBQUNMO0FBQzFEO0FBQytDO0FBQy9DO0FBQ0EsaUVBQWUsd0VBQUssQ0FBQyw4Q0FBUSxZQUFZLEVBQUM7QUFDMUM7QUFDTyxlQUFlLHdFQUFLLENBQUMsOENBQVE7QUFDcEM7QUFDTyx3QkFBd0IsZ0hBQW1CO0FBQ2xEO0FBQ0EsY0FBYyx5RUFBUztBQUN2QjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsS0FBSztBQUNMLFlBQVk7QUFDWixDQUFDOztBQUVEIiwic291cmNlcyI6WyJ3ZWJwYWNrOi8vdWxhbXVsZW1kYi8/YmY2NCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBQYWdlc0FQSVJvdXRlTW9kdWxlIH0gZnJvbSBcIm5leHQvZGlzdC9zZXJ2ZXIvZnV0dXJlL3JvdXRlLW1vZHVsZXMvcGFnZXMtYXBpL21vZHVsZS5jb21waWxlZFwiO1xuaW1wb3J0IHsgUm91dGVLaW5kIH0gZnJvbSBcIm5leHQvZGlzdC9zZXJ2ZXIvZnV0dXJlL3JvdXRlLWtpbmRcIjtcbmltcG9ydCB7IGhvaXN0IH0gZnJvbSBcIm5leHQvZGlzdC9idWlsZC90ZW1wbGF0ZXMvaGVscGVyc1wiO1xuLy8gSW1wb3J0IHRoZSB1c2VybGFuZCBjb2RlLlxuaW1wb3J0ICogYXMgdXNlcmxhbmQgZnJvbSBcIi4vcGFnZXMvYXBpL2dldC5qc1wiO1xuLy8gUmUtZXhwb3J0IHRoZSBoYW5kbGVyIChzaG91bGQgYmUgdGhlIGRlZmF1bHQgZXhwb3J0KS5cbmV4cG9ydCBkZWZhdWx0IGhvaXN0KHVzZXJsYW5kLCBcImRlZmF1bHRcIik7XG4vLyBSZS1leHBvcnQgY29uZmlnLlxuZXhwb3J0IGNvbnN0IGNvbmZpZyA9IGhvaXN0KHVzZXJsYW5kLCBcImNvbmZpZ1wiKTtcbi8vIENyZWF0ZSBhbmQgZXhwb3J0IHRoZSByb3V0ZSBtb2R1bGUgdGhhdCB3aWxsIGJlIGNvbnN1bWVkLlxuZXhwb3J0IGNvbnN0IHJvdXRlTW9kdWxlID0gbmV3IFBhZ2VzQVBJUm91dGVNb2R1bGUoe1xuICAgIGRlZmluaXRpb246IHtcbiAgICAgICAga2luZDogUm91dGVLaW5kLlBBR0VTX0FQSSxcbiAgICAgICAgcGFnZTogXCIvYXBpL2dldFwiLFxuICAgICAgICBwYXRobmFtZTogXCIvYXBpL2dldFwiLFxuICAgICAgICAvLyBUaGUgZm9sbG93aW5nIGFyZW4ndCB1c2VkIGluIHByb2R1Y3Rpb24uXG4gICAgICAgIGJ1bmRsZVBhdGg6IFwiXCIsXG4gICAgICAgIGZpbGVuYW1lOiBcIlwiXG4gICAgfSxcbiAgICB1c2VybGFuZFxufSk7XG5cbi8vIyBzb3VyY2VNYXBwaW5nVVJMPXBhZ2VzLWFwaS5qcy5tYXAiXSwibmFtZXMiOltdLCJzb3VyY2VSb290IjoiIn0=\n//# sourceURL=webpack-internal:///(api)/./node_modules/next/dist/build/webpack/loaders/next-route-loader/index.js?kind=PAGES_API&page=%2Fapi%2Fget&preferredRegion=&absolutePagePath=.%2Fpages%2Fapi%2Fget.js&middlewareConfigBase64=e30%3D!\n");

/***/ }),

/***/ "(api)/./pages/api/get.js":
/*!**************************!*\
  !*** ./pages/api/get.js ***!
  \**************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (/* binding */ handler)\n/* harmony export */ });\n/* harmony import */ var fs__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! fs */ \"fs\");\n/* harmony import */ var fs__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(fs__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var path__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! path */ \"path\");\n/* harmony import */ var path__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(path__WEBPACK_IMPORTED_MODULE_1__);\n\n\nasync function handler(req, res) {\n    // Allow only GET requests\n    if (req.method !== \"GET\") {\n        res.setHeader(\"Allow\", [\n            \"GET\"\n        ]);\n        return res.status(405).end(`Method ${req.method} Not Allowed`);\n    }\n    // Set up headers for CORS\n    res.setHeader(\"Content-Type\", \"application/json\");\n    res.setHeader(\"Access-Control-Allow-Headers\", \"*\");\n    res.setHeader(\"Access-Control-Allow-Origin\", \"*\");\n    // Get the appId from query parameters, default to \"129731987ksjdhjk\" if not provided\n    const { appId = \"129731987ksjdhjk\" } = req.query;\n    // Define file path for the appId.json file\n    const dir = path__WEBPACK_IMPORTED_MODULE_1___default().resolve(\"./public/file\");\n    const filePath = path__WEBPACK_IMPORTED_MODULE_1___default().join(dir, `${appId}.json`);\n    // Ensure the directory exists\n    if (!fs__WEBPACK_IMPORTED_MODULE_0___default().existsSync(dir)) {\n        fs__WEBPACK_IMPORTED_MODULE_0___default().mkdirSync(dir, {\n            recursive: true\n        });\n    }\n    let data = [];\n    // Check if the file exists, if it does, read its content\n    if (fs__WEBPACK_IMPORTED_MODULE_0___default().existsSync(filePath)) {\n        const rawData = fs__WEBPACK_IMPORTED_MODULE_0___default().readFileSync(filePath, \"utf8\");\n        data = JSON.parse(rawData || \"[]\"); // Fallback to empty array if rawData is empty\n    } else {\n        // If the file doesn't exist, create a new empty JSON file\n        fs__WEBPACK_IMPORTED_MODULE_0___default().writeFileSync(filePath, \"[]\");\n    }\n    // Return the data as JSON response\n    res.status(200).json({\n        data\n    });\n}\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiKGFwaSkvLi9wYWdlcy9hcGkvZ2V0LmpzIiwibWFwcGluZ3MiOiI7Ozs7Ozs7O0FBQW9CO0FBQ0k7QUFFVCxlQUFlRSxRQUFRQyxHQUFHLEVBQUVDLEdBQUc7SUFDNUMsMEJBQTBCO0lBQzFCLElBQUlELElBQUlFLE1BQU0sS0FBSyxPQUFPO1FBQ3hCRCxJQUFJRSxTQUFTLENBQUMsU0FBUztZQUFDO1NBQU07UUFDOUIsT0FBT0YsSUFBSUcsTUFBTSxDQUFDLEtBQUtDLEdBQUcsQ0FBQyxDQUFDLE9BQU8sRUFBRUwsSUFBSUUsTUFBTSxDQUFDLFlBQVksQ0FBQztJQUMvRDtJQUVBLDBCQUEwQjtJQUMxQkQsSUFBSUUsU0FBUyxDQUFDLGdCQUFnQjtJQUM5QkYsSUFBSUUsU0FBUyxDQUFDLGdDQUFnQztJQUM5Q0YsSUFBSUUsU0FBUyxDQUFDLCtCQUErQjtJQUU3QyxxRkFBcUY7SUFDckYsTUFBTSxFQUFFRyxRQUFRLGtCQUFrQixFQUFFLEdBQUdOLElBQUlPLEtBQUs7SUFFaEQsMkNBQTJDO0lBQzNDLE1BQU1DLE1BQU1WLG1EQUFZLENBQUM7SUFDekIsTUFBTVksV0FBV1osZ0RBQVMsQ0FBQ1UsS0FBSyxDQUFDLEVBQUVGLE1BQU0sS0FBSyxDQUFDO0lBRS9DLDhCQUE4QjtJQUM5QixJQUFJLENBQUNULG9EQUFhLENBQUNXLE1BQU07UUFDdkJYLG1EQUFZLENBQUNXLEtBQUs7WUFBRU0sV0FBVztRQUFLO0lBQ3RDO0lBRUEsSUFBSUMsT0FBTyxFQUFFO0lBRWIseURBQXlEO0lBQ3pELElBQUlsQixvREFBYSxDQUFDYSxXQUFXO1FBQzNCLE1BQU1NLFVBQVVuQixzREFBZSxDQUFDYSxVQUFVO1FBQzFDSyxPQUFPRyxLQUFLQyxLQUFLLENBQUNILFdBQVcsT0FBTyw4Q0FBOEM7SUFDcEYsT0FBTztRQUNMLDBEQUEwRDtRQUMxRG5CLHVEQUFnQixDQUFDYSxVQUFVO0lBQzdCO0lBRUEsbUNBQW1DO0lBQ25DVCxJQUFJRyxNQUFNLENBQUMsS0FBS2lCLElBQUksQ0FBQztRQUFFTjtJQUFLO0FBQzlCIiwic291cmNlcyI6WyJ3ZWJwYWNrOi8vdWxhbXVsZW1kYi8uL3BhZ2VzL2FwaS9nZXQuanM/NmYyNCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgZnMgZnJvbSAnZnMnO1xuaW1wb3J0IHBhdGggZnJvbSAncGF0aCc7XG5cbmV4cG9ydCBkZWZhdWx0IGFzeW5jIGZ1bmN0aW9uIGhhbmRsZXIocmVxLCByZXMpIHtcbiAgLy8gQWxsb3cgb25seSBHRVQgcmVxdWVzdHNcbiAgaWYgKHJlcS5tZXRob2QgIT09ICdHRVQnKSB7XG4gICAgcmVzLnNldEhlYWRlcignQWxsb3cnLCBbJ0dFVCddKTtcbiAgICByZXR1cm4gcmVzLnN0YXR1cyg0MDUpLmVuZChgTWV0aG9kICR7cmVxLm1ldGhvZH0gTm90IEFsbG93ZWRgKTtcbiAgfVxuXG4gIC8vIFNldCB1cCBoZWFkZXJzIGZvciBDT1JTXG4gIHJlcy5zZXRIZWFkZXIoJ0NvbnRlbnQtVHlwZScsICdhcHBsaWNhdGlvbi9qc29uJyk7XG4gIHJlcy5zZXRIZWFkZXIoJ0FjY2Vzcy1Db250cm9sLUFsbG93LUhlYWRlcnMnLCAnKicpO1xuICByZXMuc2V0SGVhZGVyKCdBY2Nlc3MtQ29udHJvbC1BbGxvdy1PcmlnaW4nLCAnKicpO1xuXG4gIC8vIEdldCB0aGUgYXBwSWQgZnJvbSBxdWVyeSBwYXJhbWV0ZXJzLCBkZWZhdWx0IHRvIFwiMTI5NzMxOTg3a3NqZGhqa1wiIGlmIG5vdCBwcm92aWRlZFxuICBjb25zdCB7IGFwcElkID0gJzEyOTczMTk4N2tzamRoamsnIH0gPSByZXEucXVlcnk7XG5cbiAgLy8gRGVmaW5lIGZpbGUgcGF0aCBmb3IgdGhlIGFwcElkLmpzb24gZmlsZVxuICBjb25zdCBkaXIgPSBwYXRoLnJlc29sdmUoJy4vcHVibGljL2ZpbGUnKTtcbiAgY29uc3QgZmlsZVBhdGggPSBwYXRoLmpvaW4oZGlyLCBgJHthcHBJZH0uanNvbmApO1xuXG4gIC8vIEVuc3VyZSB0aGUgZGlyZWN0b3J5IGV4aXN0c1xuICBpZiAoIWZzLmV4aXN0c1N5bmMoZGlyKSkge1xuICAgIGZzLm1rZGlyU3luYyhkaXIsIHsgcmVjdXJzaXZlOiB0cnVlIH0pO1xuICB9XG5cbiAgbGV0IGRhdGEgPSBbXTtcblxuICAvLyBDaGVjayBpZiB0aGUgZmlsZSBleGlzdHMsIGlmIGl0IGRvZXMsIHJlYWQgaXRzIGNvbnRlbnRcbiAgaWYgKGZzLmV4aXN0c1N5bmMoZmlsZVBhdGgpKSB7XG4gICAgY29uc3QgcmF3RGF0YSA9IGZzLnJlYWRGaWxlU3luYyhmaWxlUGF0aCwgJ3V0ZjgnKTtcbiAgICBkYXRhID0gSlNPTi5wYXJzZShyYXdEYXRhIHx8ICdbXScpOyAvLyBGYWxsYmFjayB0byBlbXB0eSBhcnJheSBpZiByYXdEYXRhIGlzIGVtcHR5XG4gIH0gZWxzZSB7XG4gICAgLy8gSWYgdGhlIGZpbGUgZG9lc24ndCBleGlzdCwgY3JlYXRlIGEgbmV3IGVtcHR5IEpTT04gZmlsZVxuICAgIGZzLndyaXRlRmlsZVN5bmMoZmlsZVBhdGgsICdbXScpO1xuICB9XG5cbiAgLy8gUmV0dXJuIHRoZSBkYXRhIGFzIEpTT04gcmVzcG9uc2VcbiAgcmVzLnN0YXR1cygyMDApLmpzb24oeyBkYXRhIH0pO1xufVxuIl0sIm5hbWVzIjpbImZzIiwicGF0aCIsImhhbmRsZXIiLCJyZXEiLCJyZXMiLCJtZXRob2QiLCJzZXRIZWFkZXIiLCJzdGF0dXMiLCJlbmQiLCJhcHBJZCIsInF1ZXJ5IiwiZGlyIiwicmVzb2x2ZSIsImZpbGVQYXRoIiwiam9pbiIsImV4aXN0c1N5bmMiLCJta2RpclN5bmMiLCJyZWN1cnNpdmUiLCJkYXRhIiwicmF3RGF0YSIsInJlYWRGaWxlU3luYyIsIkpTT04iLCJwYXJzZSIsIndyaXRlRmlsZVN5bmMiLCJqc29uIl0sInNvdXJjZVJvb3QiOiIifQ==\n//# sourceURL=webpack-internal:///(api)/./pages/api/get.js\n");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, ["vendor-chunks/next"], () => (__webpack_exec__("(api)/./node_modules/next/dist/build/webpack/loaders/next-route-loader/index.js?kind=PAGES_API&page=%2Fapi%2Fget&preferredRegion=&absolutePagePath=.%2Fpages%2Fapi%2Fget.js&middlewareConfigBase64=e30%3D!")));
module.exports = __webpack_exports__;

})();